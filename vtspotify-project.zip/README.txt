Проект Android: VTSPOTIFY
Пакет: com.webapp.vtspotify

Сборка APK:
1) GitHub: загрузите все файлы в репозиторий (вместе с папкой .github), откройте Actions -> Build APK -> Run workflow, готовый app-debug.apk будет в артефактах запуска.
2) Android Studio: File -> Open -> эта папка, затем Build -> Build APK(s).

HTML приложения лежит в app/src/main/assets/index.html.
